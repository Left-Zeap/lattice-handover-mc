from __future__ import annotations
import math
from dataclasses import dataclass
from ..physics.lattice import field_quantities, LatticeGeometry
from ..physics.waveforms import trapezoid_kinematics, linear_ramp
from ..statistics.survival import update_transport_survival, handover_end_capture
from ..statistics.diagnostics import kinetic_temperature
from ..backend import to_cpu

@dataclass
class RuntimeLattice:
    name: str
    axis: object
    geom: LatticeGeometry
    base_power_w: float
    q: float
    velocity: float
    acceleration: float
    power_fraction: float

def _random_unit_vectors(xp, rng, n):
    # Isotropic emission.
    z = rng.uniform(-1.0, 1.0, size=n)
    phi = rng.uniform(0.0, 2.0 * math.pi, size=n)
    rxy = xp.sqrt(xp.maximum(0.0, 1.0 - z*z))
    return xp.stack((rxy*xp.cos(phi), rxy*xp.sin(phi), z), axis=1)

def _apply_scattering(
    xp, rng, state, fields, runtimes, response, atom, dt
):
    """
    Quantum-jump-style recoil model.

    Event rate is local total off-resonant scattering rate.
    On an event:
      1) choose L1/L2 proportional to that lattice's local rate;
      2) choose absorption from forward/retro beam weighted by powers 1:R;
      3) emit one photon isotropically.

    This is intentionally a first-order total-scattering model; it does not yet
    resolve Rayleigh/Raman or dipole radiation patterns.
    """
    alive = state["alive"]
    if not fields:
        return

    rates = xp.stack([xp.maximum(0.0, f["gamma_sc"]) for f in fields], axis=1)
    total = xp.sum(rates, axis=1)
    p = 1.0 - xp.exp(-total * dt)
    event = alive & (rng.random(total.shape[0]) < p)
    n_event = int(to_cpu(xp.sum(event)))
    if n_event == 0:
        return

    idx = xp.where(event)[0]
    rates_e = rates[idx]
    totals_e = xp.sum(rates_e, axis=1)

    if len(fields) == 1:
        chosen = xp.zeros(n_event, dtype=xp.int32)
    else:
        # General categorical choice for the current two-lattice case.
        u = rng.random(n_event) * totals_e
        c0 = rates_e[:, 0]
        chosen = (u >= c0).astype(xp.int32)

    k = 2.0 * math.pi / response.wavelength_m
    n_emit = _random_unit_vectors(xp, rng, n_event)
    dp = -k * n_emit  # in units of hbar

    for j, (field, rt) in enumerate(zip(fields, runtimes)):
        mask_local = chosen == j
        if not bool(mask_local.any()):
            continue
        ids = idx[mask_local]
        R = float(rt.geom.retro_ratio)
        p_forward = 1.0 / (1.0 + R)
        sign = xp.where(rng.random(ids.shape[0]) < p_forward, 1.0, -1.0)
        dp[mask_local] += sign[:, None] * k * field["axis"][None, :]

    from ..constants import HBAR
    state["v"][idx] += (HBAR / atom.mass_kg) * dp
    state["scatter_count"][idx] += 1

def _forces_and_fields(xp, r, runtimes, response, gravity, atom):
    total_force = xp.tile((atom.mass_kg * gravity)[None, :], (r.shape[0], 1))
    fields = []
    active_rt = []

    for rt in runtimes:
        if rt.power_fraction <= 0.0:
            continue
        field = field_quantities(
            xp=xp,
            r=r,
            axis=rt.axis,
            q=rt.q,
            power_w=rt.base_power_w * rt.power_fraction,
            response=response,
            geom=rt.geom,
        )
        total_force -= field["gradV"]
        fields.append(field)
        active_rt.append(rt)
    return total_force, fields, active_rt

def velocity_verlet_step(
    xp, rng, state, runtimes_now, runtimes_next,
    response, atom, gravity, dt, enable_scattering
):
    F0, fields0, active0 = _forces_and_fields(
        xp, state["r"], runtimes_now, response, gravity, atom
    )
    a0 = F0 / atom.mass_kg
    state["v"] += 0.5 * dt * a0
    state["r"] += dt * state["v"]

    F1, fields1, active1 = _forces_and_fields(
        xp, state["r"], runtimes_next, response, gravity, atom
    )
    a1 = F1 / atom.mass_kg
    state["v"] += 0.5 * dt * a1

    if enable_scattering:
        _apply_scattering(
            xp, rng, state, fields1, active1, response, atom, dt
        )
    return fields1, active1

def runtime_l1(t, cfg, axis, geom):
    g = cfg["geometry"]["l1"]
    q, v, a = trapezoid_kinematics(
        t, g["distance_m"], g["duration_s"], g["acceleration_m_s2"],
        start=-g["distance_m"]
    )
    return RuntimeLattice("L1", axis, geom, g["power_w"], q, v, a, 1.0)

def runtime_handover(t, cfg, axis1, axis2, geom1, geom2):
    ho = cfg["geometry"]["handover"]
    tau = ho["duration_s"]
    f2 = linear_ramp(t, tau, 0.0, 1.0)
    f1 = 1.0 - f2
    g1 = cfg["geometry"]["l1"]
    g2 = cfg["geometry"]["l2"]
    return [
        RuntimeLattice("L1", axis1, geom1, g1["power_w"], 0.0, 0.0, 0.0, f1),
        RuntimeLattice("L2", axis2, geom2, g2["power_w"], 0.0, 0.0, 0.0, f2),
    ]

def runtime_l2(t, cfg, axis, geom):
    g = cfg["geometry"]["l2"]
    q, v, a = trapezoid_kinematics(
        t, g["distance_m"], g["duration_s"], g["acceleration_m_s2"],
        start=0.0
    )
    return RuntimeLattice("L2", axis, geom, g["power_w"], q, v, a, 1.0)

def record_diag(xp, state, atom, t_abs, stage, n0):
    d = kinetic_temperature(xp, state["v"], state["alive"], atom.mass_kg)
    total_sc = int(to_cpu(xp.sum(state["scatter_count"])))
    return {
        "time_s": float(t_abs),
        "stage": stage,
        "survival": d["n_alive"] / n0,
        "n_alive": d["n_alive"],
        "T_K": d["T_K"],
        "Tx_K": d["Tx_K"],
        "Ty_K": d["Ty_K"],
        "Tz_K": d["Tz_K"],
        "scatter_events_total": total_sc,
    }

def propagate_experiment(
    xp, rng, state, cfg, atom, response, geom1, geom2, axis1, axis2
):
    dt = float(cfg["simulation"]["dt_s"])
    rec_dt = float(cfg["simulation"]["record_interval_s"])
    scat = bool(cfg["simulation"]["enable_scattering"])
    surv_cfg = cfg["simulation"]["survival"]
    check_every = int(surv_cfg.get("check_every_steps", 1))
    gravity = xp.asarray(cfg["geometry"]["gravity_m_s2"], dtype=float)
    n0 = state["r"].shape[0]

    history = []
    next_record = 0.0
    t_abs = 0.0
    history.append(record_diag(xp, state, atom, t_abs, "L1", n0))

    # ---------- L1 ----------
    T1 = float(cfg["geometry"]["l1"]["duration_s"])
    nsteps = int(math.ceil(T1 / dt))
    for i in range(nsteps):
        t0 = min(i * dt, T1)
        t1 = min((i + 1) * dt, T1)
        h = t1 - t0
        rt0 = [runtime_l1(t0, cfg, axis1, geom1)]
        rt1 = [runtime_l1(t1, cfg, axis1, geom1)]
        fields, active = velocity_verlet_step(
            xp, rng, state, rt0, rt1, response, atom, gravity, h, scat
        )

        if fields and (((i + 1) % check_every == 0) or i == nsteps - 1):
            elapsed_check = h * (check_every if (i + 1) % check_every == 0 else ((i + 1) % check_every))
            update_transport_survival(
                xp, state, fields[0], rt1[0].velocity, rt1[0].acceleration,
                atom, elapsed_check, surv_cfg
            )

        t_abs = t1
        if t_abs + 1e-15 >= next_record + rec_dt or i == nsteps - 1:
            history.append(record_diag(xp, state, atom, t_abs, "L1", n0))
            next_record = t_abs

    # ---------- handover ----------
    TH = float(cfg["geometry"]["handover"]["duration_s"])
    nsteps = int(math.ceil(TH / dt))
    ho_start = t_abs
    for i in range(nsteps):
        t0 = min(i * dt, TH)
        t1 = min((i + 1) * dt, TH)
        h = t1 - t0
        rt0 = runtime_handover(t0, cfg, axis1, axis2, geom1, geom2)
        rt1 = runtime_handover(t1, cfg, axis1, axis2, geom1, geom2)
        velocity_verlet_step(
            xp, rng, state, rt0, rt1, response, atom, gravity, h, scat
        )
        t_abs = ho_start + t1
        if t_abs + 1e-15 >= next_record + rec_dt or i == nsteps - 1:
            history.append(record_diag(xp, state, atom, t_abs, "handover", n0))
            next_record = t_abs

    # End-of-handover L2 capture.
    rt2 = runtime_l2(0.0, cfg, axis2, geom2)
    field2 = field_quantities(
        xp, state["r"], axis2, rt2.q, rt2.base_power_w,
        response, geom2
    )
    handover_end_capture(
        xp, state, field2, 0.0, 0.0, atom, surv_cfg
    )
    history.append(record_diag(xp, state, atom, t_abs, "handover_end", n0))

    # ---------- L2 ----------
    T2 = float(cfg["geometry"]["l2"]["duration_s"])
    nsteps = int(math.ceil(T2 / dt))
    l2_start = t_abs
    for i in range(nsteps):
        t0 = min(i * dt, T2)
        t1 = min((i + 1) * dt, T2)
        h = t1 - t0
        rt0 = [runtime_l2(t0, cfg, axis2, geom2)]
        rt1 = [runtime_l2(t1, cfg, axis2, geom2)]
        fields, active = velocity_verlet_step(
            xp, rng, state, rt0, rt1, response, atom, gravity, h, scat
        )

        if fields and (((i + 1) % check_every == 0) or i == nsteps - 1):
            elapsed_check = h * (check_every if (i + 1) % check_every == 0 else ((i + 1) % check_every))
            update_transport_survival(
                xp, state, fields[0], rt1[0].velocity, rt1[0].acceleration,
                atom, elapsed_check, surv_cfg
            )

        t_abs = l2_start + t1
        if t_abs + 1e-15 >= next_record + rec_dt or i == nsteps - 1:
            history.append(record_diag(xp, state, atom, t_abs, "L2", n0))
            next_record = t_abs

    return history, state
