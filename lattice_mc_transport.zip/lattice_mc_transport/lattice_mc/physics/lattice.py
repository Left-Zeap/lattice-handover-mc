from __future__ import annotations
from dataclasses import dataclass
import math

@dataclass
class LatticeGeometry:
    axis: object
    s_points: tuple[float, float]
    waist_points_m: tuple[float, float]
    retro_ratio: float
    phase_offset_rad: float = 0.0

def unit_vector(xp, vec):
    v = xp.asarray(vec, dtype=float)
    return v / xp.sqrt(xp.sum(v * v))

def waist_and_slope(xp, s, s_points, waist_points_m):
    """
    Piecewise-linear waist model between two source-supported endpoint values.
    Outside the interval the waist is clamped and dw/ds = 0.

    This is deliberately configurable: replace with measured/Gaussian waist(z)
    when the exact optical geometry is available.
    """
    s0, s1 = s_points
    w0, w1 = waist_points_m
    slope = (w1 - w0) / (s1 - s0)
    f = (s - s0) / (s1 - s0)
    f_clip = xp.clip(f, 0.0, 1.0)
    w = w0 + f_clip * (w1 - w0)
    active = (f >= 0.0) & (f <= 1.0)
    dwds = xp.where(active, slope, 0.0)
    return w, dwds

def field_quantities(
    xp,
    r,
    axis,
    q,
    power_w,
    response,
    geom: LatticeGeometry,
):
    """
    Exact unequal-retro standing-wave intensity plus analytic gradient.

    I_f = 2P/(pi w^2) exp(-2 rho^2/w^2)
    I = I_f [(1+R)+2 sqrt(R) cos(2 theta)]
    theta = k(s-q)+phase_offset

    Returns dict with total intensity, gradI, local waist, local axial
    barrier U_ax, local antinode depth U_peak and phase coordinate.
    """
    e = unit_vector(xp, axis)
    s = xp.sum(r * e[None, :], axis=1)
    r_perp = r - s[:, None] * e[None, :]
    rho2 = xp.sum(r_perp * r_perp, axis=1)

    w, dwds = waist_and_slope(xp, s, geom.s_points, geom.waist_points_m)
    If = 2.0 * power_w / (math.pi * w**2) * xp.exp(-2.0 * rho2 / w**2)

    R = float(geom.retro_ratio)
    sr = math.sqrt(R)
    k = 2.0 * math.pi / response.wavelength_m
    theta = k * (s - q) + float(geom.phase_offset_rad)
    B = (1.0 + R) + 2.0 * sr * xp.cos(2.0 * theta)
    intensity = If * B

    # d ln(If) / ds due to the configurable axial waist profile.
    dlnIf_ds = dwds * (-2.0 / w + 4.0 * rho2 / w**3)
    dB_ds = -4.0 * sr * k * xp.sin(2.0 * theta)

    grad_ax_scalar = If * (dlnIf_ds * B + dB_ds)
    grad_rad = If[:, None] * B[:, None] * (-4.0 * r_perp / w[:, None]**2)
    gradI = grad_ax_scalar[:, None] * e[None, :] + grad_rad

    # Conservative potential U = C_U I.
    V = response.shift_per_intensity * intensity
    gradV = response.shift_per_intensity * gradI

    # Local forward center intensity (rho=0) at this axial location.
    If0 = 2.0 * power_w / (math.pi * w**2)
    absC = abs(response.shift_per_intensity)
    Uax = absC * If0 * (4.0 * sr)
    Upeak = absC * If0 * (1.0 + sr)**2
    Vmin = -Upeak if response.shift_per_intensity < 0 else 0.0

    gamma_sc = response.scatter_per_intensity * intensity

    return {
        "V": V,
        "gradV": gradV,
        "gamma_sc": gamma_sc,
        "w": w,
        "rho2": rho2,
        "s": s,
        "Uax": Uax,
        "Upeak": Upeak,
        "Vmin": Vmin,
        "axis": e,
        "k": k,
    }

def tilted_barrier(xp, Uax, k, mass, acceleration):
    """
    Local downhill barrier for -U cos^2(kx) + m a x.

    Returns zero when |a| >= a_c.
    """
    ac = Uax * k / mass
    beta = xp.where(ac > 0.0, abs(acceleration) / ac, xp.inf)
    clipped = xp.clip(beta, 0.0, 1.0)
    F = xp.sqrt(xp.maximum(0.0, 1.0 - clipped**2)) - clipped * xp.arccos(clipped)
    return xp.where(beta < 1.0, Uax * F, 0.0)
