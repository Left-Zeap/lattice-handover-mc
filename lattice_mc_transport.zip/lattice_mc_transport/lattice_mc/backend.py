from __future__ import annotations

def get_backend(name: str = "auto"):
    """
    Return (xp, resolved_name).

    xp is numpy or cupy and exposes a NumPy-like API.
    """
    name = name.lower()
    if name not in {"auto", "cpu", "gpu"}:
        raise ValueError("backend must be auto/cpu/gpu")

    if name in {"auto", "gpu"}:
        try:
            import cupy as cp
            # Force a tiny runtime check; import alone can succeed with unusable CUDA.
            _ = cp.zeros(1)
            return cp, "gpu"
        except Exception:
            if name == "gpu":
                raise RuntimeError(
                    "GPU backend requested but CuPy/CUDA is unavailable. "
                    "Install a matching CuPy build, e.g. cupy-cuda12x."
                )

    import numpy as np
    return np, "cpu"


def to_cpu(x):
    try:
        import cupy as cp
        if isinstance(x, cp.ndarray):
            return cp.asnumpy(x)
    except Exception:
        pass
    return x
